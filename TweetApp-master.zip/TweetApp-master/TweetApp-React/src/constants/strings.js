export const pages = {
   LOGIN: "Login",
   FORGOT_PASSWORD: "Forgot Password",
   REGISTER: "Register",
   MY_TWEETS: "My Tweets",
   ALL_USERS: "ALL_USERS",
   HOME: "Home"
};